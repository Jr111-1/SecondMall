package com.lqf.fleamarket.controller.param;

import lombok.Data;

/**
 * @Description detail
 * Created by lqf on 2021/5/16 21:12
 */
@Data
public class UserStatusReq {
    private int role;
}
