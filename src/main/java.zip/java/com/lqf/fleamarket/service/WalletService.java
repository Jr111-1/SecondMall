package com.lqf.fleamarket.service;

public interface WalletService {
}
