package com.lqf.fleamarket.dao.entity;

import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;

@Data
@Table(name = "tbl_wallet")
@Entity
@DynamicUpdate
@DynamicInsert

public class WalletEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private long ownerId;
    private float money;
    private String payContent;
    private String saveContent;
}
